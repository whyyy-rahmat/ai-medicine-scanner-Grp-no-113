# MediScan - AI Medicine Scanner

A web application that scans medicine labels or barcodes using AI to provide detailed information about the medicine.

## Project Overview

The goal of this project is to build an AI-based medicine scanner that can read the name of a medicine from a barcode or label and provide important details about it. After scanning, the backend system connects to an online drugs website to fetch and return medicine information.

## Features

- **Medicine Scanning**: Scan medicine labels or barcodes using camera or file upload
- **Information Retrieval**: Get detailed information about the medicine including:
  - Generic name
  - Dosage information
  - Manufacturer details
  - Uses
  - Side effects
  - How to take
  - Warnings and precautions

## Technologies Used

- **Frontend**:
  - HTML5
  - CSS3 (with responsive design)
  - JavaScript (vanilla)
- **Backend** (to be connected):
  - API for processing scanned images
  - Database connection to medicine information source

## File Structure

- `index.html` - Main HTML file with the application structure
- `styles.css` - CSS styling for the application
- `script.js` - JavaScript with interactive functionality

## Setup Instructions

1. Clone this repository
2. Open `index.html` in a web browser to view the frontend
3. For full functionality, connect to the backend API (modify the API_URL in script.js)

## How It Works

1. **Scan**: User takes a photo of medicine label or barcode
2. **Process**: The backend AI analyzes the image and identifies the medicine
3. **Fetch**: The system fetches detailed information from trusted medical databases
4. **Display**: The application presents the information in an organized, user-friendly format

## For Developers

- The current implementation includes mock data for demonstration purposes
- To connect to a real backend API, modify the `API_URL` constant in `script.js`
- The API should return data in the same format as the mock data structure

## Project Context

This is a capstone project for the CSDA course at IIT Patna, 1st semester. The frontend portion was created using HTML, CSS, and JavaScript.

## Contributors

- [Your Name] - Frontend Development

## Disclaimer

This application is for educational purposes only. Always consult healthcare professionals before making medical decisions based on the information provided. 